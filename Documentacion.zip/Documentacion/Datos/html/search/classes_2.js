var searchData=
[
  ['salescontroller_0',['SalesController',['../class_web_application1_1_1_controllers_1_1_sales_controller.html',1,'WebApplication1::Controllers']]]
];
