var searchData=
[
  ['productscontroller_0',['ProductsController',['../class_web_application1_1_1_controllers_1_1_products_controller.html#a006cc9c7fb75a61c2519eb73c6f5cbb4',1,'WebApplication1::Controllers::ProductsController']]]
];
