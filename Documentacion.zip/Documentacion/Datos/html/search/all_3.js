var searchData=
[
  ['salescontroller_0',['SalesController',['../class_web_application1_1_1_controllers_1_1_sales_controller.html#a8b709bac794e457cf5a3c486e7bc37f4',1,'WebApplication1.Controllers.SalesController.SalesController()'],['../class_web_application1_1_1_controllers_1_1_sales_controller.html',1,'WebApplication1.Controllers.SalesController']]],
  ['salescontroller_2ecs_1',['SalesController.cs',['../_sales_controller_8cs.html',1,'']]]
];
