var searchData=
[
  ['get_0',['Get',['../class_web_application1_1_1_controllers_1_1_login_users_controller.html#a1e03afcdaec93fea26c35c47f3e31f80',1,'WebApplication1.Controllers.LoginUsersController.Get()'],['../class_web_application1_1_1_controllers_1_1_products_controller.html#ab62cd25d8643fd125b4005984d47e190',1,'WebApplication1.Controllers.ProductsController.Get()'],['../class_web_application1_1_1_controllers_1_1_sales_controller.html#a16265de65e9f8e34e09180b08f91da84',1,'WebApplication1.Controllers.SalesController.Get()']]]
];
