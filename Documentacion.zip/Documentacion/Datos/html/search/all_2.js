var searchData=
[
  ['productscontroller_0',['ProductsController',['../class_web_application1_1_1_controllers_1_1_products_controller.html#a006cc9c7fb75a61c2519eb73c6f5cbb4',1,'WebApplication1.Controllers.ProductsController.ProductsController()'],['../class_web_application1_1_1_controllers_1_1_products_controller.html',1,'WebApplication1.Controllers.ProductsController']]],
  ['productscontroller_2ecs_1',['ProductsController.cs',['../_products_controller_8cs.html',1,'']]]
];
