$(document).ready(function () {
    $('#sideHome').on('click', function(){
        loadProducts();
    });

    $('#txtSearchProducts').on('keypress', function(){
        searchTextProducts();
    });

    $('#txtSearchProducts').on('blur', function(){
        loadCardsProducts();
    });

    $('.input-group').on('click', '.button-plus', function(e) {
        incrementValue(e);
    });

    $('.input-group').on('click', '.button-minus', function(e) {
        decrementValue(e);
    });

    $('#btnAddCarProducts').on('click', function () { 
        addCartProduct();
     });

     $('#btnViewCar').on('click', function(){  
        $('#viewModaladdCar').modal('show'); 
        viewModalCar(); 
     });

     $('#btnSales').on('click', function () {
         finishSale();
     });

     $('#btnCancelSales').on('click', function () {
        finishCancelSale();
    });

    loadCardsProducts();
});

function loadProducts(){
    let params = new URLSearchParams(location.search);
    var contract = params.get('param');
    $("#formModules").attr("src",'./../Products/Products.html?param=' + contract);
}

function loadCardsProducts() {
    try {
        $.ajax({
            type: "get",
            url: 'https://localhost:44384/api/Products/consultProducts',
            dataType: 'json',
            data: {
                IdParam: 1,
                Codigo: "a",
                Nombre: "a",
                Valor: "a",
                Image: "a",
                Descripcion: "a"
            },
            contenType: "application/json; charset=utf-8",
            complete: function (r) {
                let json = '';
                json = r.responseJSON;
    
                renderCardProducts(json);
            }
        });
    } catch (error) {
        console.log('Error al cargar tarjetas:' + error);
    }
}

function renderCardProducts (json){
    let data = json;
    let card = '';

    if(data) {
        $('#cardSeccion').html('');

        $.each(data, function(i,o){
         card += '<div class="col-sm3 col-md-3 col-lg-3 col-xl-3 mb-4">'
         card += '<div class="card" style="width: 18rem;" onclick="detailsCard('+"'"+ o.idProducto + "'" + ')">'
         card += '<img src="../../'+o.imgProducto+'" class="card-img-top img-card" alt="...">'
         card += '<div class="card-body">'
         card += '<p class="card-text">'+o.nomProducto+'</p>'
         card += '<h5 class="card-text">'+o.valor+'</h5>'
         card += '</div>'
         card += '</div>'
         card += '</div>'
        });
    } else {
        $('#cardSeccion').html('');
        card += '<h5 class="card-text"><<No se encuentra resultados de busqueda...>></h5>'
    }

    $('#cardSeccion').append(card);
}

function detailsCard(id) {
    
    try {
        $.ajax({
            url: 'https://localhost:44384/api/Products/consultProducts',
            dataType: 'json',
            data: {
                IdParam: 4,
                Codigo: id.toString(),
                Nombre: "na",
                Valor: "na",
                Image: "na",
                Descripcion: "na"
            },
            contenType: "application/json; charset=utf-8",
            success: function (r) { 
    
            },
            complete: function (r) {
                var jsonmod = ''
    
                jsonmod = r.responseJSON;
                if(jsonmod){
                    viewModalProducts(jsonmod);
                }
            },
        })
    } catch (error) {
        console.log('Error al cargar detalle de productos cliente:' + error);
    }
}

function viewModalProducts(jsonmod){
    let dato = jsonmod[0];
    $('#imgModal').attr('src', '../../'+dato.imgProducto);
    $('#titleModal').text(dato.nomProducto);
    $('#codeModal').text(dato.codProducto);
    $('#descModal').text(dato.descripcion);
    $('#valueModal').text(dato.valor);
    $('#lblIdProdctClient').val(dato.idProducto);

    $('#viewModalProducts').modal('show');
}

function searchTextProducts(){
    let valTxtSearch = $('#txtSearchProducts').val();

    if(valTxtSearch.length > 2){
        searchProductsDetail(valTxtSearch);
    } else {
        loadCardsProducts();
    }
}

function searchProductsDetail(value){
    try {
        $.ajax({
            type: "get",
            url: 'https://localhost:44384/api/Products/consultProducts',
            dataType: 'json',
            data: {
                IdParam: 6,
                Codigo: "a",
                Nombre: value,
                Valor: "a",
                Image: "a",
                Descripcion: "a"
            },
            contenType: "application/json; charset=utf-8",
            complete: function (r) {
                let json = '';
                json = r.responseJSON;
    
                renderCardProducts(json);
            }
        });
    } catch (error) {
        console.log('Error al consultar productos detalle cliente' + error);
    }
}

function incrementValue(e) {
    e.preventDefault();
    var fieldName = $(e.target).data('field');
    var parent = $(e.target).closest('div');
    var currentVal = parseInt(parent.find('input[name=' + fieldName + ']').val(), 10);

    if (!isNaN(currentVal)) {
        parent.find('input[name=' + fieldName + ']').val(currentVal + 1);
    } else {
        parent.find('input[name=' + fieldName + ']').val(0);
    }
}

function decrementValue(e) {
    e.preventDefault();
    var fieldName = $(e.target).data('field');
    var parent = $(e.target).closest('div');
    var currentVal = parseInt(parent.find('input[name=' + fieldName + ']').val(), 10);

    if (!isNaN(currentVal) && currentVal > 0) {
        parent.find('input[name=' + fieldName + ']').val(currentVal - 1);
    } else {
        parent.find('input[name=' + fieldName + ']').val(0);
    }
}

function addCartProduct(){
    let valCantProduct = $('#inpCantProduct').val() ? $('#inpCantProduct').val() : "na";
    let valIdProduct= $('#lblIdProdctClient').val() ? $('#lblIdProdctClient').val() : "na";
    let valNameUser = nameUserProduct();

    try {
        $.ajax({
            type: "get",
            url: 'https://localhost:44384/api/Sales/consultSales?',
            dataType: 'json',
            data: {
                IdParam: 2,
                IdProducto: valIdProduct,
                CantidadVenta: parseInt(valCantProduct),
                NomUsuario: valNameUser
            },
            contenType: "application/json; charset=utf-8",
            complete: function (r) {
                if(r.status = 200){
                    $('#viewModalProducts').modal('hide');
                    alert('Producto agregado al carrito de compras');
                }
            }
        });
    } catch (error) {
        console.log('Error agregando producto al carrito de compras:' + error)
    }
}

function nameUserProduct(){
    let params = new URLSearchParams(location.search);
    var contract = params.get('param');
    if(contract){
        let result = JSON.parse(atob(contract));
        return result[0].nombre;
    } else {
        return "na";
    }
}

function viewModalCar(){
    let valNameUser = nameUserProduct();
    try {
        $.ajax({
            type: "get",
            url: 'https://localhost:44384/api/Sales/consultSales?',
            dataType: 'json',
            data: {
                IdParam: 1,
                IdProducto: "na",
                CantidadVenta: 0,
                NomUsuario: valNameUser
            },
            contenType: "application/json; charset=utf-8",
            complete: function (r) {
                let json = '';
                json = r.responseJSON;
                
                if(r.status == 200){
                    renderTableCard(json);
                }
            }
        });
        
    } catch (error) {
        console.log('Error Cargando dataTable Carrito de compras' + error);
    }
}


function renderTableCard(json){
    let dato = json;

    $('#TableAddCar').DataTable({
        data: dato,
        columns: [
            {
                title: "Nombre Producto",
                className: "wrap",
                data: "descProductoVenta"
            },
            {
                title: "Cantidad",
                className: "wrap",
                data: "detCantidadVenta"
            },
            {
                title: "Fecha",
                className: "wrap",
                data: "detFchVenta"
            },
            {
                title: "Valor",
                className: "wrap",
                data: "detValorVenta"
            },
            {
                title: "Eliminar",
                data: function (row) {
                    let html = '';
                    html = '<button type="button" btn-elm-grill class="btn btn-primary" data-id="' + row.detIdVenta + '" onclick="deleteProductsCar(' + row.detIdVenta + ')"> - </button>'
                    return html;
                },
                className: "wrap",
                "width": "5%"
            },
        ]
    });
}

function deleteProductsCar(id){
    let valNameUser = nameUserProduct();

    try {
        $.ajax({
            type: "get",
            url: 'https://localhost:44384/api/Sales/consultSales?',
            dataType: 'json',
            data: {
                IdParam: 3,
                IdProducto: "na",
                CantidadVenta: id,
                NomUsuario: valNameUser
            },
            contenType: "application/json; charset=utf-8",
            complete: function (r) {
                if(r.status = 200){
                    $('#TableAddCar').DataTable().destroy();
                    $('#TableAddCar').html('');
                    viewModalCar();
                }
            }
        });
    } catch (error) {
        console.log('Error al eliminar productos del carrito' + error)
    }
}

function finishSale() {
    let valNameUser = nameUserProduct();
    try {
        $.ajax({
            type: "get",
            url: 'https://localhost:44384/api/Sales/consultSales?',
            dataType: 'json',
            data: {
                IdParam: 4,
                IdProducto: "na",
                CantidadVenta: 0,
                NomUsuario: valNameUser
            },
            contenType: "application/json; charset=utf-8",
            complete: function (r) {
                if(r.status = 200){
                    finishCancelSale();
                    alert('compra finalizada');
                }
            }
        });
    } catch (error) {
        console.log('Error al finalizar compra');
    }
}

function finishCancelSale() {
    $('#TableAddCar').DataTable().destroy();
    $('#TableAddCar').html('');
    $('#viewModaladdCar').modal('hide'); 
}