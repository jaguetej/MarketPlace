$(document).ready(function () {

    $('#btnLogin').on('click', function(){
        logIn(1);
    });

    $('#btnLogOut').on('click', function(){
        logIn(2);
    });

    validateParam();
});


function logIn(item) {
    if(item == 1){
        validateLoginUsers();
    } else {
        $(location).attr('href','../../Index.html');
    }
}

function validateLoginUsers(){
    let elements = $('.elementsLogin');
    let txtAlert = '';
    let contElements = 0;

    $.each(elements, function(i,o){
        let txtElement = false;
        txtElement = !!$('#'+ o.id).val();

        if(!txtElement) {
            txtAlert = txtAlert + ', ' + o.labels[0].innerHTML;
            contElements++;
            $('#'+ o.id).addClass('color-validacion');
        } else {
            $('#'+ o.id).removeClass('color-validacion');
        }
    });

    if(contElements > 0){
        alert('Debe registrar los campos' + txtAlert);
    } else {        
        let txtEmail = $('#txtEmail').val();
        let textPass = $('#txtPass').val();

        if (txtEmail.indexOf('@', 0) == -1 || txtEmail.indexOf('.', 0) == -1) {
            alert('Debe ingresar una direccion Email valida.');
            $('#txtEmail').addClass('color-validacion');
        } else {
            $('#txtEmail').removeClass('color-validacion');
            accesAplication(txtEmail, textPass);
        }
    }
}

function accesAplication(txtEmail, textPass){
    $.ajax({
        type: "get",
        url: 'https://localhost:44384/api/LoginUsers',
        dataType: 'json',
        data: {
            Email: txtEmail,
            Pass: textPass
        },
        contenType: "application/json; charset=utf-8",
        complete: function (r) {
            let json;
            json = r.responseJSON;
            allowModules(json);
        }
    });
}

function allowModules(data){
    let param = btoa(JSON.stringify(data));
    if(data[0].idUsuario == 1){
            $(location).attr('href','Components/Autentication/Aplication.html?param=' + param);
    } else {
        alert('Usuario no registrado');
    }
}

function validateParam(){
    let params = new URLSearchParams(location.search);
    var contract = params.get('param');
    if(contract){
        let result = JSON.parse(atob(contract));
        
        if(result[0].tipoUsuario == 1){
            $('.AdminAplication').prop('hidden', false);
            $('.CustomerAplication').prop('hidden', true);
            $('#iconUser').removeClass('far fa-user-circle').addClass('fas fa-user-tie');
        } else {
            $('.AdminAplication').prop('hidden', true);
            $('.CustomerAplication').prop('hidden', false);
            $('#iconUser').removeClass('fas fa-user-tie').addClass('far fa-user-circle');
        }
        $('#txtUser').text(result[0].nombre);
    }
}