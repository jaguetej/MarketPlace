var imgData = '';

$(document).ready(function () {
    $('#sideAdmin').on('click', function(){
        loadMasters();
    });

    $('#btnClearProd').on('click', function(){
        clearMasters();
    });

    $('#btnAddProd').on('click', function(){
        validateMasters();
    });

    $('#imgProd').on('change', function(){
        selectImage();
    });

    $('#btnUpdateMaster').on('click', function(){
        validateUpdateProducts();
    });

    $('.form-check-input').on('click', function(){
        radioTopSales();
    });

    loadTableMasters();
});

function loadMasters(){
    $("#formModules").attr("src",'./../Masters/Masters.html');
}

function selectImage(){

    var blobFile = $('#imgProd').prop('files')[0];
    var reader = new FileReader();
    reader.readAsDataURL(blobFile);
    reader.onloadend = function () {
        // console.log(reader.result);
        // document.getElementById("img").src = reader.result;
        imgData = blobFile;
    }
}

function clearMasters(){
    $('.product').val('');
}

function validateMasters(){
    let elements = $('.product');
    let txtAlert = '';
    let contElements = 0;

    $.each(elements, function(i,o){
        let txtElement = false;
        txtElement = !!$('#'+ o.id).val();

        if(!txtElement) {
            txtAlert = txtAlert + ', ' + o.labels[0].innerHTML;
            contElements++;
        }
    });

    if(contElements > 0){
        alert('Debe registrar los campos' + txtAlert);
    } else {
        saveMastersProducts();
    }
}

function loadTableMasters() {
    try {
        $.ajax({
            type: "get",
            url: 'https://localhost:44384/api/Products/consultProducts',
            dataType: 'json',
            data: {
                IdParam: 1,
                Codigo: "na",
                Nombre: "na",
                Valor: "na",
                Image: "na",
                Descripcion: "na"
            },
            contenType: "application/json; charset=utf-8",
            complete: function (r) {
                let json = '';
                json = r.responseJSON;
    
                renderTableProducts(json);
            }
        });
    } catch (error) {
        console.log('Error al cargar productos:' + error);
    }
}

function renderTableProducts(json){
    let dato = json;

    $('#TableConsultaProducts').DataTable({
        data: dato,
        columns: [
            {
                title: "Codigo Producto",
                className: "wrap",
                data: "codProducto"
            },
            {
                title: "Nombre",
                className: "wrap",
                data: "nomProducto"
            },
            {
                title: "Valor",
                className: "wrap",
                data: "valor"
            },
            {
                title: "Descripcion",
                className: "wrap",
                data: "descripcion"
            },
            {
                title: "Editar",
                data: function (row) {
                    let html = '';
                    html = '<button type="button" btn-edit-grill class="btn btn-primary" data-id="' + row.idProducto + '" onclick="loadDetailProducts(' + row.idProducto + ')">+</button>'
                    return html;
                },
                className: "wrap",
                "width": "5%"
            },
            {
                title: "Eliminar",
                data: function (row) {
                    let html = '';
                    html = '<button type="button" btn-elm-grill class="btn btn-primary" data-id="' + row.idProducto + '" onclick="deleteProducts(' + row.idProducto + ')"> - </button>'
                    return html;
                },
                className: "wrap",
                "width": "5%"
            },
        ]
    });
}

function saveMastersProducts(){
    let varCod = $('#txtProdCod').val();
    let varNomb = $('#txtProdNombre').val();
    let varValue = $('#txtProdPrecio').val();
    let varImg = "Images\\" + imgData.name;
    let varDesc = $('#txtProdDesc').val();

    try {
    
        $.ajax({
            type: "get",
            url: 'https://localhost:44384/api/Products/consultProducts',
            dataType: 'json',
            data: {
                IdParam: 2,
                Codigo: varCod,
                Nombre: varNomb,
                Valor: varValue,
                Image: varImg,
                Descripcion: varDesc
            },
            contenType: "application/json; charset=utf-8",
            success: function(r){
            },
            complete: function(r){
                if(r.status = 200){
                    $('#TableConsultaProducts').DataTable().destroy();
                    $('#TableConsultaProducts').html('');
                    loadTableMasters();
    
                    alert('Producto agregado correctamente');
                }
            }
        });
    } catch (error) {
        console.log('Error al registrar productos:' + error);
    }
}

function deleteProducts(id){
    try {
        $.ajax({
            type: "get",
            url: 'https://localhost:44384/api/Products/consultProducts',
            dataType: 'json',
            data: {
                IdParam: 3,
                Codigo: id.toString(),
                Nombre: "na",
                Valor: "na",
                Image: "na",
                Descripcion: "na"
            },
            contenType: "application/json; charset=utf-8",
            complete: function (r) {
                if(r.status = 200){
                    $('#TableConsultaProducts').DataTable().destroy();
                    $('#TableConsultaProducts').html('');
                    loadTableMasters();

                    alert('Producto eliminado correctamente');
                }
            }
        });
    } catch (error) {
        console.log('Error al eliminar productos:' + error);
    }
}

function loadDetailProducts(id) {
    try {
        $.ajax({
            url: 'https://localhost:44384/api/Products/consultProducts',
            dataType: 'json',
            data: {
                IdParam: 4,
                Codigo: id.toString(),
                Nombre: "na",
                Valor: "na",
                Image: "na",
                Descripcion: "na"
            },
            contenType: "application/json; charset=utf-8",
            success: function (r) { 
    
            },
            complete: function (r) {
                var jsonmod = ''
    
                jsonmod = r.responseJSON;
                if(jsonmod){
                    viewModal(jsonmod);
                }
            },
        })
    } catch (error) {
        console.log('Error al cargar detalle de productos:' + error);
    }
}

function viewModal(jsonmod){
    let dato = jsonmod[0];
    $('#imgModal').attr('src', '../../'+dato.imgProducto);
    $('#titleModal').text(dato.nomProducto);
    $('#inputProdCod').val(dato.codProducto);
    $('#inputProdDesc').val(dato.descripcion);
    $('#inputProdValue').val(dato.valor);
    $('#lblCodUpdate').val(dato.codProducto);

    $('#viewModalMasters').modal('show');
}

function validateUpdateProducts(){
    let elements = $('.updateProduct');
    let txtAlert = '';
    let contElements = 0;

    $.each(elements, function(i,o){
        let txtElement = false;
        txtElement = !!$('#'+ o.id).val();

        if(!txtElement) {
            txtAlert = txtAlert + ', ' + o.labels[0].innerHTML;
            contElements++;
        }
    });

    if(contElements > 0){
        alert('Debe registrar los campos' + txtAlert);
    } else {
        updateProducts();
    }
}

function updateProducts() {
    let varCod = $('#inputProdCod').val();
    let varValue = $('#inputProdValue').val();
    let varDesc = $('#inputProdDesc').val();
    let lblCod = $('#lblCodUpdate').val();

    try {
        $.ajax({
            url: 'https://localhost:44384/api/Products/consultProducts',
            dataType: 'json',
            data: {
                IdParam: 5,
                Codigo: varCod,
                Nombre: lblCod,
                Valor: varValue,
                Image: "na",
                Descripcion: varDesc
            },
            contenType: "application/json; charset=utf-8",
            complete: function (r) {
                if(r.status = 200){
                    $('#TableConsultaProducts').DataTable().destroy();
                    $('#TableConsultaProducts').html('');
                    loadTableMasters();
                    $('#viewModalMasters').modal('hide');
                    alert('Producto actualizado con exito.');
                }
            },
        })
    } catch (error) {
        console.log('Error al actualizar producto' + error);
    }
}

function radioTopSales() {
    if($('#radTopSales').prop('checked')){
        viewTopSales('1');
    } else if ($('#radLowSales').prop('checked')) {
        viewTopSales('2');
    }
}

function viewTopSales(val){
    try {
        $.ajax({
            type: "get",
            url: 'https://localhost:44384/api/Products/consultProducts',
            dataType: 'json',
            data: {
                IdParam: 7,
                Codigo: val,
                Nombre: "na",
                Valor: "na",
                Image: "na",
                Descripcion: "na"
            },
            contenType: "application/json; charset=utf-8",
            complete: function (r) {
                let json = '';
                json = r.responseJSON;
                if(json){
                    $('#TableConsultaProducts').DataTable().destroy();
                    $('#TableConsultaProducts').html('');
                    renderTableProducts(json);
                }
            }
        });
    } catch (error) {
        console.log('Error al cargar Top productos:' + error);
    }
}