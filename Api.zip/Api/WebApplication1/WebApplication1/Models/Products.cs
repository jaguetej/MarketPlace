﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    /// <summary>
    /// Clase Productos
    /// </summary>
    public class Products
    {
        /// <summary>
        /// Id producto
        /// </summary>
        public int IdProducto { get; set; }
        /// <summary>
        /// Codigo producto
        /// </summary>
        public string CodProducto { get; set; }
        /// <summary>
        /// Nombre del producto
        /// </summary>
        public string NomProducto { get; set; }
        /// <summary>
        /// Valor del producto
        /// </summary>
        public string Valor { get; set; }
        /// <summary>
        /// Imagen de registro del producto
        /// </summary>
        public string ImgProducto { get; set; }
        /// <summary>
        /// Descripción del producto
        /// </summary>
        public string Descripcion { get; set; }
    }
}
