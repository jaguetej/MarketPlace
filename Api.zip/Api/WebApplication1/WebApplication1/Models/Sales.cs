﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class Sales
    {
        /// <summary>
        /// Id Venta
        /// </summary>
        public int detIdVenta { get; set; }
        /// <summary>
        /// Descripcion producto
        /// </summary>
        public string descProductoVenta { get; set; }
        /// <summary>
        /// Cantidad Venta
        /// </summary>
        public int detCantidadVenta { get; set; }
        /// <summary>
        /// Fecha Venta
        /// </summary>
        public string detFchVenta { get; set; }
        /// <summary>
        /// Valor venta
        /// </summary>
        public string detValorVenta { get; set; }
    }
}
