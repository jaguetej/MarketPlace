﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class Users
    {
        /// <summary>
        /// Codigo del usuario
        /// </summary>
        public int IdUsuario { get; set; }
        /// <summary>
        /// Nombre o Descripcion usuario
        /// </summary>
        public string Nombre { get; set; }
        /// <summary>
        /// Direccion Email usuario
        /// </summary>
        public string Email { get; set; }
        /// <summary>
        /// Contraseña usuario
        /// </summary>
        public string PassWord { get; set; }
        /// <summary>
        /// Tipo de usuario
        /// </summary>
        public int TipoUsuario { get; set; }
    }
}
