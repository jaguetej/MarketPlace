﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Models;
using WebApplication1.Services;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : Controller
    {
        /// <summary>
        /// Repository
        /// </summary>
        private readonly ProductsRepository productsRepository;
        /// <summary>
        /// logger
        /// </summary>
        private readonly ILogger<ProductsController> logger;

        /// <summary>
        /// Constructor Clase
        /// </summary>
        public ProductsController(ILogger<ProductsController> logger)
        {
            this.productsRepository = new ProductsRepository();
            this.logger = logger;
        }
        
        /// <summary>
        /// Metodo Productos
        /// </summary>
        /// <param name="IdParam"></param>
        /// <param name="Codigo"></param>
        /// <param name="Nombre"></param>
        /// <param name="Valor"></param>
        /// <param name="Image"></param>
        /// <param name="Descripcion"></param>
        /// <returns></returns>
        [Route("consultProducts")]
        public async Task<IActionResult> Get(int IdParam, string Codigo, string Nombre, string Valor, string Image, string Descripcion)
        {
            logger.LogInformation($"Inicia ProductsController/get(int IdParam, string Codigo, string Nombre, string Valor, string Image, string Descripcion)");
            logger.LogDebug($"Inicia ProductsController/get(int IdParam:{IdParam},string Codigo: {Codigo} ,string Nombre:{Nombre} ,string Valor:{Valor} ,string Image:{Image} ,string Descripcion:{Descripcion})");

            return await Task.Run(() =>
            {
                try
                {
                    var value = productsRepository.GetAllProducts(IdParam, Codigo, Nombre, Valor, Image, Descripcion);

                    logger.LogInformation($"Termina ProductsController/get(int IdParam, string Codigo, string Nombre, string Valor, string Image, string Descripcion)");
                    return Ok(value);
                }
                catch(Exception ex)
                {
                    logger.LogError($"Error ProductsController/get(int IdParam:{IdParam},string Codigo: {Codigo} ,string Nombre:{Nombre} ,string Valor:{Valor} ,string Image:{Image} ,string Descripcion:{Descripcion})");
                    return StatusCode(500, ex);
                }
            });
        }
    }
}
