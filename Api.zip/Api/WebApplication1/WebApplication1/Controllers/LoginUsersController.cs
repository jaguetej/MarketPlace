﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Services;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LoginUsersController : Controller
    {
        /// <summary>
        /// Repository
        /// </summary>
        private readonly UsersRepository usersRepository;
        /// <summary>
        /// logger
        /// </summary>
        private readonly ILogger<LoginUsersController> logger;

        /// <summary>
        /// Constructor Clase
        /// </summary>
        public LoginUsersController(ILogger<LoginUsersController> logger)
        {
            this.usersRepository = new UsersRepository();
            this.logger = logger;
        }

        /// <summary>
        /// Consulta Login Usuarios
        /// </summary>
        /// <param name="Email"></param>
        /// <param name="Pass"></param>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> Get(string Email, string Pass)
        {
            logger.LogInformation($"Inicia LoginUsersController/Get(string Email, string Pass)");
            logger.LogDebug($"Inicia LoginUsersController/get(string Email:{Email}), string Pass:{Pass})");

            return await Task.Run(() =>
            {
                try
                {
                    var value = usersRepository.GetUsers(Email, Pass);

                    logger.LogInformation($"Termina LoginUsersController/Get(string Email, string Pass)");
                    return Ok(value);
                }
                catch (Exception ex)
                {
                    logger.LogError($"Error LoginUsersController/get(string Email:{Email}), string Pass:{Pass})");
                    return StatusCode(500, ex);
                }
            });
        }
    }
}
