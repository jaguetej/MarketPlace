﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Models;
using WebApplication1.Services;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SalesController : Controller
    {
        /// <summary>
        /// Repository
        /// </summary>
        private readonly SalesRepository salesRepository;
        /// <summary>
        /// logger
        /// </summary>
        private readonly ILogger<SalesController> logger;

        /// <summary>
        /// Constructor Clase
        /// </summary>
        public SalesController(ILogger<SalesController> logger)
        {
            this.salesRepository = new SalesRepository();
            this.logger = logger;
        }
        /// <summary>
        /// Metodo Ventas
        /// </summary>
        /// <param name="IdParam"></param>
        /// <param name="IdProducto"></param>
        /// <param name="CantidadVenta"></param>
        /// <param name="NomUsuario"></param>
        /// <returns></returns>
        [Route("consultSales")]
        public async Task<IActionResult> Get(int IdParam, string IdProducto, int CantidadVenta, string NomUsuario)
        {
            logger.LogInformation($"Inicia SalesController/get(int IdParam, string IdProducto, int CantidadVenta, string NomUsuario)");
            logger.LogDebug($"Inicia SalesController/get(int IdParam:{IdParam},string IdProducto: {IdProducto} ,int CantidadVenta:{CantidadVenta} ,string NomUsuario:{NomUsuario})");

            return await Task.Run(() =>
            {
                try
                {
                    var value = salesRepository.GetAllSales(IdParam, IdProducto, CantidadVenta, NomUsuario);

                    logger.LogInformation($"Termina SalesController/get(int IdParam, string IdProducto, int CantidadVenta, string NomUsuario)");
                    return Ok(value);
                }
                catch (Exception ex)
                {
                    logger.LogError($"Error SalesController/get(int IdParam:{IdParam},string IdProducto: {IdProducto} ,int CantidadVenta:{CantidadVenta} ,string NomUsuario:{NomUsuario})");
                    return StatusCode(500, ex);
                }
            });
        }
    }
}
