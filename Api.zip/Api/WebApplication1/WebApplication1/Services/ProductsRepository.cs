﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Models;

namespace WebApplication1.Services
{
    public class ProductsRepository
    {
        /// <summary>
        /// Obtiene cadena de Conexion
        /// </summary>
        /// <returns></returns>
        private static SqlConnection NewDBConnection()
        {

            SqlConnection sconn = new SqlConnection("Data Source = localhost\\SQLEXPRESS; Initial Catalog = master; Integrated Security = True");
            return sconn;
        }

        /// <summary>
        /// Repositorio de productos
        /// </summary>
        /// <param name="IdParam"></param>
        /// <param name="Codigo"></param>
        /// <param name="Nombre"></param>
        /// <param name="Valor"></param>
        /// <param name="Image"></param>
        /// <param name="Descripcion"></param>
        /// <returns></returns>
        public List<Products> GetAllProducts(int IdParam, string Codigo, string Nombre, string Valor, string Image, string Descripcion)
        {
            var result = new List<Products>();

            using (SqlConnection cadena = NewDBConnection())
            {
                using (SqlCommand cmd = new SqlCommand("SPGETProductos", cadena))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@Idparam", IdParam));
                    cmd.Parameters.Add(new SqlParameter("@Codigo", Codigo));
                    cmd.Parameters.Add(new SqlParameter("@Nombre", Nombre));
                    cmd.Parameters.Add(new SqlParameter("@Valor", Valor));
                    cmd.Parameters.Add(new SqlParameter("@Image", Image));
                    cmd.Parameters.Add(new SqlParameter("@Descripcion", Descripcion));

                    cadena.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Products tmprecord = new Products()
                            {
                                IdProducto = int.Parse(reader[0].ToString()),
                                CodProducto = reader[1].ToString(),
                                NomProducto = reader[2].ToString(),
                                Valor = reader[3].ToString(),
                                ImgProducto = reader[4].ToString(),
                                Descripcion = reader[5].ToString()
                            };
                            result.Add(tmprecord);
                        }
                    }
                }
                return result;
            }
        }
    }
}
