﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Models;

namespace WebApplication1.Services
{
    public class SalesRepository
    {
        /// <summary>
        /// Obtiene cadena de Conexion
        /// </summary>
        /// <returns></returns>
        private static SqlConnection NewDBConnection()
        {

            SqlConnection sconn = new SqlConnection("Data Source = localhost\\SQLEXPRESS; Initial Catalog = master; Integrated Security = True");
            return sconn;
        }
        /// <summary>
        /// Repositorio de ventas
        /// </summary>
        /// <param name="IdParam"></param>
        /// <param name="IdProducto"></param>
        /// <param name="CantidadVenta"></param>
        /// <param name="NomUsuario"></param>
        /// <returns></returns>
        public List<Sales> GetAllSales(int IdParam, string IdProducto, int CantidadVenta, string NomUsuario)
        {
            var result = new List<Sales>();

            using (SqlConnection cadena = NewDBConnection())
            {
                using (SqlCommand cmd = new SqlCommand("SPGETVENTASPRODUCTOS", cadena))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@Idparam", IdParam));
                    cmd.Parameters.Add(new SqlParameter("@IdProducto", IdProducto));
                    cmd.Parameters.Add(new SqlParameter("@CantidadVenta", CantidadVenta));
                    cmd.Parameters.Add(new SqlParameter("@NomUsuario", NomUsuario));

                    cadena.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Sales tmprecord = new Sales()
                            {
                                detIdVenta = int.Parse(reader[0].ToString()),
                                descProductoVenta = reader[1].ToString(),
                                detCantidadVenta = int.Parse(reader[2].ToString()),
                                detFchVenta = reader[3].ToString(),
                                detValorVenta = reader[4].ToString()
                            };
                            result.Add(tmprecord);
                        }
                    }
                }
                return result;
            }
        }
    }
}
