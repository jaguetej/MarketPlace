﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Models;

namespace WebApplication1.Services
{
    public class UsersRepository
    {
        /// <summary>
        /// Obtiene cadena de Conexion
        /// </summary>
        /// <returns></returns>
        private static SqlConnection NewDBConnection()
        {

            SqlConnection sconn = new SqlConnection("Data Source = localhost\\SQLEXPRESS; Initial Catalog = master; Integrated Security = True");
            return sconn;
        }


        public List<Users> GetUsers(string Email, string Pass)
        {
            var result = new List<Users>();

            using (SqlConnection cadena = NewDBConnection())
            {
                using (SqlCommand cmd = new SqlCommand("SPGETUSUARIOS", cadena))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@Email", Email));
                    cmd.Parameters.Add(new SqlParameter("@PassWord", Pass));

                    cadena.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Users tmprecord = new Users()
                            {
                                IdUsuario = int.Parse(reader[0].ToString()),
                                Nombre = reader[1].ToString(),
                                Email = reader[2].ToString(),
                                PassWord = reader[3].ToString(),
                                TipoUsuario = int.Parse(reader[4].ToString())
                            };
                            result.Add(tmprecord);
                        }
                    }
                }
                return result;
            }
        }
    }
}
